<?php

class Food {
    public $x;
    public $y;
    public $value;

    public function __construct($opions = null)
    {
        if ($opions) {
            $this->x = $opions->x;
            $this->y = $opions->y;
            $this->value = $opions->value;
        }
    }
}
