<?php

require_once 'Command.php';

class Input {

    const COMMAND = COMMAND;
    private $logic;

    public function __construct($logic){
        $this->logic = $logic;

    }

    // Получить команды
    public function getCommand() {
        return (object) self::COMMAND;
    }

    // Выполнить команду
    public function executeCommand($name, $options = null) {
        if ( $name ) {
            print_r($name);
            print_r($options);
//            return $this->logic->{$name}($options);
            return $this->logic->{$name}($options);
        }
        return false;
    }

}