<?php
// Все команды, которые будут в нашей


const COMMAND = [
    'CHANGE_DIRECTION' => 'changeDirection', // изменить направление змеи
    'MOVE_SNAKE' => 'moveSnake', // подвинуть змею на 1 клетку
    'DESTROY_SNAKE' => 'destroySnake', // уничтожить змею
    'CREATE_SNAKE' => 'createSnake', // создать змею
    'GET_SNAKE' => 'getSnake', // получить змею
    'ADD_FOOD' => 'addFood', // добавить еду
    'GET_FOOD' => 'getFood', // получить еду
    'EAT_FOOD' => 'eatFood', // съесть еду
    'UPDATE_SCENE' => 'updateScene', // обновить сцену/получить данные
];
