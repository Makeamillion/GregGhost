<?php

// TODO :: Переписать функции как changeDirection, везде одна переменная $options
// TODO :: Функции с маленькой буквы
// TODO :: Сделать проверку за выход границ
// TODO :: Если наезжает на хвост другой змеи то сжирает, другая змея короче становится
// TODO :: Проверка, не оказалась ли на другой змее

class Logic {
    private $struct;

    public function __construct($struct)
    {
        $this->struct = $struct;
    }

	//
	// Удав. Логика
	//
	
	// Получить удава
    private function getSnake($options)
    {
        if ($options && $options->id) {
            $snakes = $this->struct->snakes;
            foreach ($snakes as $snake) {
                if ($snake->id === $options->id) {
                    return $snake;
                }
            }
        }
        return false;
    }
	// Создать удава
    private function createSnake($options)
    {
        if($options && $options->snake) {
            $this->struct->snakes[] = new Snake($options->snake);
            return true;
        }
        return false;
    }
	// Уничтожить удава
    private function destroySnake($options)
    {
        if ($options && $options->id) {
            $id = $options->id;
            $snakes = $this->struct->snake;
            foreach ($snakes as $key => $snake) {
                if ($snake->id === $id) {
                    unset($this->struct->snakes[$key]);
                    return true;
                }
            }
        }
        return false;
    }
	// Подвинуть удава на 1 клетку
    public function moveSnake($options)
    {
        // TODO :: сделать проверку за выход границ
        if ($options && $options->id) {
            $snake = $this->getSnake($options->id);
            if ($snake) {
                switch ($snake->direction) {
                    case 'up':
                        $snake->y = $snake->y - 1;
                        break;
                    case 'down':
                        $snake->y = $snake->y + 1;
                        break;
                    case 'left':
                        $snake->x = $snake->x - 1;
                        break;
                    case 'right':
                        $snake->x = $snake->x + 1;
                        break;
                }
                return true;
            }
        }
        return false;
    }
	// Изменить направление удава
    public function changeDirection($options = null)
    {
        print_r("test");
        if ($options && $options->id && $options ->direction) {
            $snake = $this->getSnake($options->id);
            if ($snake) {
                $snake->direction = $options->direction;
                return true;
            }
        }
        return false;
    }
	
	//
	// Еда. Логика
	//
	
	// Добавить новую еду на карту
    private function addFood($options)
    {
        if ($options && $options->food) {
            $this->struct->foods[] = new Food($options->food);
        }
        return false;
    }
	// Получить еду
    private function getFood($options)
    {
        if ($options && $options->id) {
            $foods = $this->struct->foods;
            foreach ($foods as $food) {
                if ($food->id === $options->id) {
                    return $food;
                }
            }
        }
        return false;
    }
	// Съесть еду
    private function eatFood($options)
    {
        if($options && $options->id) {
            $foods = $this->struct->foods;
            foreach ($foods as $key => $food) {
                if ($food->id === $options->id) {
                    unset($this->struct->foods[$key]);
                    return true;
                }
            }
        }
        return false;
    }
}
